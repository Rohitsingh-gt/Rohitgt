#!/usr/bin/python3

import telebot
import requests
import datetime
import time
import os

# ================= CONFIG =================
BOT_TOKEN = "8245251931:AAFyFE88RoXlUIsIfqD4-1ZTt0kfFlRfnXU"

bot = telebot.TeleBot(BOT_TOKEN)

ADMIN_IDS = ["6293907676"]

USER_FILE = "users.txt"
LOG_FILE = "log.txt"

API_URL = "http://127.0.0.1:8000/start-test"
API_KEY = "mysecurekey123"

COOLDOWN = 10
last_used = {}

# ================= FILE UTILS =================
def read_users():
    try:
        with open(USER_FILE, "r") as f:
            return f.read().splitlines()
    except:
        return []

def save_user(user_id):
    with open(USER_FILE, "a") as f:
        f.write(user_id + "\n")

allowed_users = read_users()

# ================= LOGGING =================
def log(user_id, text):
    with open(LOG_FILE, "a") as f:
        f.write(f"{datetime.datetime.now()} | {user_id} | {text}\n")

# ================= ADMIN COMMANDS =================
@bot.message_handler(commands=['add'])
def add_user(msg):
    if str(msg.chat.id) not in ADMIN_IDS:
        return bot.reply_to(msg, "❌ Admin only")

    try:
        uid = msg.text.split()[1]
        if uid not in allowed_users:
            allowed_users.append(uid)
            save_user(uid)
            bot.reply_to(msg, "✅ User added")
        else:
            bot.reply_to(msg, "⚠️ Already exists")
    except:
        bot.reply_to(msg, "Usage: /add <user_id>")

@bot.message_handler(commands=['remove'])
def remove_user(msg):
    if str(msg.chat.id) not in ADMIN_IDS:
        return bot.reply_to(msg, "❌ Admin only")

    try:
        uid = msg.text.split()[1]
        if uid in allowed_users:
            allowed_users.remove(uid)
            with open(USER_FILE, "w") as f:
                for u in allowed_users:
                    f.write(u + "\n")
            bot.reply_to(msg, "✅ Removed")
        else:
            bot.reply_to(msg, "Not found")
    except:
        bot.reply_to(msg, "Usage: /remove <user_id>")

@bot.message_handler(commands=['allusers'])
def all_users(msg):
    if str(msg.chat.id) not in ADMIN_IDS:
        return

    if not allowed_users:
        return bot.reply_to(msg, "No users")

    text = "Users:\n" + "\n".join(allowed_users)
    bot.reply_to(msg, text)

@bot.message_handler(commands=['broadcast'])
def broadcast(msg):
    if str(msg.chat.id) not in ADMIN_IDS:
        return

    try:
        text = msg.text.split(" ",1)[1]
        for u in allowed_users:
            try:
                bot.send_message(u, text)
            except:
                pass
        bot.reply_to(msg, "✅ Sent")
    except:
        bot.reply_to(msg, "Usage: /broadcast message")

# ================= USER COMMANDS =================
@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "🤖 Bot Ready\nUse /help")

@bot.message_handler(commands=['help'])
def help_cmd(msg):
    bot.reply_to(msg, """
Commands:
/test url threads requests
/mylogs
/feedback message
""")

# ================= TEST COMMAND =================
@bot.message_handler(commands=['test'])
def test(msg):
    uid = str(msg.chat.id)

    if uid not in ADMIN_IDS:
        return bot.reply_to(msg, "❌ Admin only")

    now = time.time()
    if uid in last_used:
        rem = COOLDOWN - (now - last_used[uid])
        if rem > 0:
            return bot.reply_to(msg, f"⏳ Wait {int(rem)} sec")

    try:
        args = msg.text.split()
        url = args[1]
        threads = int(args[2])
        reqs = int(args[3])
    except:
        return bot.reply_to(msg, "Usage: /test url threads requests")

    last_used[uid] = now
    bot.reply_to(msg, "⚡ Running test...")

    try:
        r = requests.post(
            f"{API_URL}?key={API_KEY}",
            json={
                "url": url,
                "threads": threads,
                "requests_per_thread": reqs
            }
        )

        data = r.json()

        result = f"""
✅ Done

URL: {data['url']}
Threads: {data['threads']}
Requests: {data['requests_per_thread']}

Success: {data['success']}
Fail: {data['fail']}
Time: {data['time_taken']}s
"""
        bot.send_message(msg.chat.id, result)
        log(uid, f"TEST {url}")

    except Exception as e:
        bot.reply_to(msg, f"Error: {e}")

# ================= LOGS =================
@bot.message_handler(commands=['mylogs'])
def mylogs(msg):
    uid = str(msg.chat.id)

    try:
        with open(LOG_FILE) as f:
            logs = [l for l in f if uid in l]
            bot.reply_to(msg, "".join(logs) if logs else "No logs")
    except:
        bot.reply_to(msg, "No logs")

# ================= FEEDBACK =================
@bot.message_handler(commands=['feedback'])
def feedback(msg):
    text = msg.text.replace("/feedback","").strip()

    if not text:
        return bot.reply_to(msg, "Usage: /feedback message")

    for admin in ADMIN_IDS:
        bot.send_message(admin, f"""
📩 Feedback

User: {msg.from_user.first_name}
ID: {msg.chat.id}

{text}
""")

    bot.reply_to(msg, "✅ Sent")

# ================= RUN =================
bot.polling()